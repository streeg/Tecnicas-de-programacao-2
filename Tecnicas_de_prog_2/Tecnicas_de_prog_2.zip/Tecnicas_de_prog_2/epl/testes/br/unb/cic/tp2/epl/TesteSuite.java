package br.unb.cic.tp1.epl;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
 AddTest.class,
 SubTest.class,
 MultTest.class,
 LiteralTest.class
})
public class TestSuite {

}