Guilherme Andreúce Sobreira Monteiro 14/0141961 e Maria Fernanda do Carmo Oliveira

Implementação da feature subtraction e multiplication.
