package br.unb.cic.epl.spl;

public interface Expression {
	public String print();
}